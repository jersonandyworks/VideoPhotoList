<?php
/*
 * Plugin Name: Post Video & Photo list
 * Plugin URI: http://jersoncv.davaobuyers.com
 * Description: This plugin works for adding videos & photos on any posts or pages
 * Author: Jerson Andy Barrios
 * Author URI: http://jersoncv.davaobuyers.com
 * 
 * 
 * Copyright YEAR  Jerson Andy Barrios  (email : barriosjerson@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * */

// Create short codes
function youtube_video_list($attr,$video_id,$content=null)
{
	$attr = shortcode_atts(array('title'=>'My Default Title',
	                             'video_id'=>!empty($video_id) ? : 'VdvEdMMtNMY',
	                             'thumbnail'=>1),$attr);
    
   extract($attr);
    return "<div style='float:left; margin-right:10px;'><h2>$title</h2>
            <p><a href='http://www.youtube.com/watch?v=$video_id' target='_blank'><img src='http://img.youtube.com/vi/$video_id/$thumbnail.jpg'></a></p></div>";
}
add_shortcode('youtube_list','youtube_video_list');


