VideoPhotoList
==============

This is a plugin that will create a video list on youtube with thumbnail, If an image will be clicked it will open on a new tab